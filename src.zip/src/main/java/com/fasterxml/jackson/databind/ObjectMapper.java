package com.fasterxml.jackson.databind;

import webd4201.shine.User;

public class ObjectMapper {

	public String writeValueAsString(User testUser) {
		// TODO Auto-generated method stub
		
		
		
		return null;
	}

}
